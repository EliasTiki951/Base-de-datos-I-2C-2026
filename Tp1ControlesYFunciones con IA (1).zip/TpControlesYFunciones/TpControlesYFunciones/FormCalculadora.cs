using System;
using System.Windows.Forms;

namespace TpControlesYFunciones
{
    /// <summary>
    /// Ejercicio 1: calcula el importe final de una venta según tipo de cliente y medio de pago.
    /// Toda la matemática vive en funciones; el evento solo lee, valida, invoca y muestra.
    /// </summary>
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
            cmbTipoCliente.SelectedIndex = 0;   // "Regular" por defecto
            rbEfectivo.Checked = true;          // medio de pago por defecto
        }

        // ---------------------------------------------------------------
        // Funciones de lógica (sin acceso a controles, reutilizables)
        // ---------------------------------------------------------------

        /// <summary>Porcentaje de descuento: Regular 0%, Socio 10%, VIP 20%.</summary>
        private decimal CalcularPorcentajeDescuento(string tipoCliente)
        {
            switch (tipoCliente)
            {
                case "Socio": return 0.10m;
                case "VIP":   return 0.20m;
                default:      return 0.0m;   // Regular
            }
        }

        /// <summary>Convierte el porcentaje de descuento en un importe (monto * porcentaje).</summary>
        private decimal CalcularValorDescuento(decimal montoBase, decimal porcentaje)
        {
            return montoBase * porcentaje;
        }

        /// <summary>Recargo del 5% si se paga con tarjeta; 0 en caso contrario.</summary>
        private decimal CalcularRecargoMedioPago(bool esTarjeta, decimal monto)
        {
            return esTarjeta ? monto * 0.05m : 0m;
        }

        /// <summary>Monto final = base - descuento + recargo.</summary>
        private decimal ObtenerMontoFinal(decimal montoBase, decimal descuento, decimal recargo)
        {
            return montoBase - descuento + recargo;
        }

        // ---------------------------------------------------------------
        // Evento
        // ---------------------------------------------------------------

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // 1) Leer entradas
            string cliente = txtCliente.Text.Trim();
            decimal montoBase = numMonto.Value;
            string tipoCliente = cmbTipoCliente.SelectedItem?.ToString();
            bool esTarjeta = rbTarjeta.Checked;

            // 2) Validar
            if (cliente.Length == 0)
            {
                MessageBox.Show("Ingresá el nombre del cliente.", "Dato faltante",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCliente.Focus();
                return;
            }
            if (string.IsNullOrEmpty(tipoCliente))
            {
                MessageBox.Show("Seleccioná el tipo de cliente.", "Dato faltante",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbTipoCliente.Focus();
                return;
            }
            if (montoBase <= 0)
            {
                MessageBox.Show("El monto base debe ser mayor a 0.", "Monto inválido",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                numMonto.Focus();
                return;
            }

            // 3) Invocar las funciones
            decimal porcentaje = CalcularPorcentajeDescuento(tipoCliente);
            decimal descuento  = CalcularValorDescuento(montoBase, porcentaje);
            decimal recargo    = CalcularRecargoMedioPago(esTarjeta, montoBase);
            decimal montoFinal = ObtenerMontoFinal(montoBase, descuento, recargo);

            // 4) Formatear y mostrar
            lblResultado.Text =
                $"Cliente: {cliente} ({tipoCliente})\n" +
                $"Medio de pago: {(esTarjeta ? "Tarjeta" : "Efectivo")}\n" +
                "\n" +
                $"Monto base:   {montoBase:C2}\n" +
                $"Descuento ({porcentaje:P0}):   -{descuento:C2}\n" +
                $"Recargo medio de pago:   +{recargo:C2}\n" +
                "------------------------------------\n" +
                $"TOTAL:   {montoFinal:C2}";
        }
    }
}
