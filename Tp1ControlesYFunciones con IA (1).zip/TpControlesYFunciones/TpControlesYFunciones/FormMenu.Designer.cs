using System;
using System.Drawing;
using System.Windows.Forms;

namespace TpControlesYFunciones
{
    partial class FormMenu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitulo = new Label();
            btnEjercicio1 = new Button();
            btnEjercicio2 = new Button();
            btnEjercicio3 = new Button();
            SuspendLayout();
            //
            // lblTitulo
            //
            lblTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTitulo.Location = new Point(20, 15);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(320, 50);
            lblTitulo.Text = "TP: Funciones y manejo de eventos en C# WinForms";
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;
            //
            // btnEjercicio1
            //
            btnEjercicio1.Location = new Point(40, 80);
            btnEjercicio1.Name = "btnEjercicio1";
            btnEjercicio1.Size = new Size(280, 40);
            btnEjercicio1.Text = "Ejercicio 1: Calculadora de descuentos";
            btnEjercicio1.UseVisualStyleBackColor = true;
            btnEjercicio1.Click += new EventHandler(btnEjercicio1_Click);
            //
            // btnEjercicio2
            //
            btnEjercicio2.Location = new Point(40, 130);
            btnEjercicio2.Name = "btnEjercicio2";
            btnEjercicio2.Size = new Size(280, 40);
            btnEjercicio2.Text = "Ejercicio 2: Validador de contraseñas";
            btnEjercicio2.UseVisualStyleBackColor = true;
            btnEjercicio2.Click += new EventHandler(btnEjercicio2_Click);
            //
            // btnEjercicio3
            //
            btnEjercicio3.Location = new Point(40, 180);
            btnEjercicio3.Name = "btnEjercicio3";
            btnEjercicio3.Size = new Size(280, 40);
            btnEjercicio3.Text = "Ejercicio 3: Conversor de unidades";
            btnEjercicio3.UseVisualStyleBackColor = true;
            btnEjercicio3.Click += new EventHandler(btnEjercicio3_Click);
            //
            // FormMenu
            //
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(360, 250);
            Controls.Add(lblTitulo);
            Controls.Add(btnEjercicio1);
            Controls.Add(btnEjercicio2);
            Controls.Add(btnEjercicio3);
            Font = new Font("Segoe UI", 10F);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FormMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TP Controles y Funciones";
            ResumeLayout(false);
        }

        private Label lblTitulo;
        private Button btnEjercicio1;
        private Button btnEjercicio2;
        private Button btnEjercicio3;
    }
}
